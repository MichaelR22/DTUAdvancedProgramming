/**
 * Module for assignment1 of the course 02324 in spring 2025.
 */
module dk.dtu.compute.course02324.assignment1 {

    requires validation.api;
    requires javafx.controls;

    exports dk.dtu.compute.course02324.assignment2.genericstack.types;
    exports dk.dtu.compute.course02324.assignment2.genericstack.uses;

}